// LIVESCRIPT - Estruturas de Dados - Listas, Vetores ou Mapas.
console.log("Estruturas de Dados - Listas, Vetores ou Mapas.");
