# LOGOS - Variáveis e Tipos - Como armazenar dados.
print("Variáveis e Tipos - Como armazenar dados.")
