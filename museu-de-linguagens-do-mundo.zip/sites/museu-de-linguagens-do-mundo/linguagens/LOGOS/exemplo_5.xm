# LOGOS - Funções - Criando blocos de código reutilizáveis.
print("Funções - Criando blocos de código reutilizáveis.")
