% LOGTALK - Funções - Criando blocos de código reutilizáveis.
main :-
    write('Funções - Criando blocos de código reutilizáveis.'), nl.
    halt.
