# LSL - Matemática - Operações aritméticas básicas.
print("Matemática - Operações aritméticas básicas.")
