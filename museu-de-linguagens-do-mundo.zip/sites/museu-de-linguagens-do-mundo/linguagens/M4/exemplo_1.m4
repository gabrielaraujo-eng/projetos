# M4 - Olá Mundo - O básico de qualquer linguagem.
print("Olá Mundo - O básico de qualquer linguagem.")
