# M4 - Conceito Avançado - Um pequeno algoritmo (ex: Fibonacci).
print("Conceito Avançado - Um pequeno algoritmo (ex: Fibonacci).")
