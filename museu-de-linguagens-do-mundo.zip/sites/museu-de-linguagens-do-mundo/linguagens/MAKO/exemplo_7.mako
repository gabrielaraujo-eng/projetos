# MAKO - Tratamento de Erros - Lidando com exceções e falhas.
print("Tratamento de Erros - Lidando com exceções e falhas.")
