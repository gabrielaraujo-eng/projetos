<!-- MARKDOWN - Variáveis e Tipos - Como armazenar dados. -->
<div>Variáveis e Tipos - Como armazenar dados.</div>
